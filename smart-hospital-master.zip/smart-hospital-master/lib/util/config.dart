class AppConfig {
  /*
  uncomment jika menggunakan real device, cocokkan alamat server dengan ip address komputer/laptop anda
  */
  static const String API_ENDPOINT = "http://192.168.43.104/smart-hospital/";

  /*
  uncomment jika menggunakan emulator android
  */
  // static const String API_ENDPOINT = "http://10.0.2.2/smart-hospital/";
}
