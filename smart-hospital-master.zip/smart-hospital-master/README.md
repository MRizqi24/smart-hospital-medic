# smart_hospital

A new Flutter projects.

## Getting Started

Ini adalah source code aplikasi smart hospital android.

Pada repository ini disediakan project dalam 2 versi (branch):

- [Non Null Safety: sdk >=2.7.0 <3.0.0](https://gitlab.com/smart-hospital-flutter/smart-hospital)
- [Null Safety: sdk >=2.14.0 <3.0.0](https://gitlab.com/smart-hospital-flutter/smart-hospital/-/tree/null-safety-ver)

Silahkan disesuaikan dengan kebutuhan anda.
